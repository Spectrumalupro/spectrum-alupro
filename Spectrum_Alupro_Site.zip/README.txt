To jest projekt React dla strony internetowej firmy Spectrum Alupro.
Zalecane do wdrożenia przez Vercel lub Netlify.